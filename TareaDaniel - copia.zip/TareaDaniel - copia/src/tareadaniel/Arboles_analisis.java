package tareadaniel;

public class Arboles_analisis {
    public static void main(String[] args) {
        // hojas 
        Nodo tres = new Nodo("3");
        Nodo cinco = new Nodo("5");
        Nodo dos = new Nodo("2");

        // suma: 3 + 5
        Nodo suma = new Nodo("+");
        suma.izquierda = tres;
        suma.derecha = cinco;

        // multiplicacin: (3+5) * 2
        Nodo multi = new Nodo("*");
        multi.izquierda = suma;
        multi.derecha = dos;

        System.out.println("Resultado de (3+5)*2 = " + evaluar(multi));
    }

    public static double evaluar(Nodo nodo) {
        // condicionali si es una hoja con un valor, se retorna el mismo valor
        if (nodo.izquierda == null && nodo.derecha == null) {
            return Double.parseDouble(nodo.valor);
        }

        // recursividad a los subarboles
        double izquierda = evaluar(nodo.izquierda);
        double derecha = evaluar(nodo.derecha);

        // resolucion según el operador
        switch (nodo.valor) {
            case "+":
                return izquierda + derecha;
            case "-":
                return izquierda - derecha;
            case "*":
                return izquierda * derecha;
            case "/":
                if (derecha == 0) {
                    throw new ArithmeticException("no se puede dividir entre cero");
                }
                return izquierda / derecha;
            default:
                throw new IllegalArgumentException("operador desconocido: " + nodo.valor);
        }
    }
}