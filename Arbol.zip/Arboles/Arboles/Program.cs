﻿using System;

namespace arbolesanalisis
{
    public class nodo
    {
        public string valor;
        public nodo izquierda;
        public nodo derecha;

        public nodo(string valor)
        {
            this.valor = valor;
            this.izquierda = null;
            this.derecha = null;
        }
    }

    class program
    {
        static void Main(string[] args)
        {
            nodo tres = new nodo("3");
            nodo cinco = new nodo("5");
            nodo dos = new nodo("2");

            nodo suma = new nodo("+");
            suma.izquierda = tres;
            suma.derecha = cinco;

            nodo multi = new nodo("*");
            multi.izquierda = suma;
            multi.derecha = dos;

            Console.WriteLine("resultado es = " + evaluar(multi));
        }

        static double evaluar(nodo n)
        {
            if (n.izquierda == null && n.derecha == null)
            {
                return double.Parse(n.valor);
            }

            double izquierda = evaluar(n.izquierda);
            double derecha = evaluar(n.derecha);

            switch (n.valor)
            {
                case "+": return izquierda + derecha;
                case "-": return izquierda - derecha;
                case "*": return izquierda * derecha;
                case "/":
                    if (derecha == 0)
                        throw new DivideByZeroException("estas bobo no se puede dividir entre cero");
                    return izquierda / derecha;
                default:
                    throw new ArgumentException("incorrecto " + n.valor);
            }
        }
    }
}